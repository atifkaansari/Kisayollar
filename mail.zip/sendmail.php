<?php

error_reporting(E_ALL);
ini_set("display_errors", 1);




use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';



$mail = new PHPMailer(true);
try {
 //Server settings
 $mail->CharSet = 'UTF-8';
 $mail->SMTPDebug = 0; // debug on - off
 $mail->isSMTP(); 
 $mail->Host = ''; // SMTP sunucusu örnek : mail.alanadi.com
 $mail->SMTPAuth = true; // SMTP Doğrulama
 $mail->Username = ''; // Mail kullanıcı adı
 $mail->Password = ''; // Mail şifresi
 $mail->SMTPSecure = ''; // Şifreleme
 $mail->Port = ; // SMTP Port
$mail->SMTPOptions = array(
 'ssl' => array(
 'verify_peer' => false,
 'verify_peer_name' => false,
 'allow_self_signed' => true
 )
);

 //Alıcılar
 $mail->setfrom('', '');
 $mail->addAddress('');
 $mail->addReplyTo('', $_POST['name']);
 //İçerik
 $mail->isHTML(true);
 $mail->Subject = $_POST['subject'];
 $mail->Body = $_POST['message'];

 $mail->send();
 header("Location: ../index.html");
die();
} catch (Exception $e) {
 echo 'Mesajınız İletilemedi. Hata: ', $mail->ErrorInfo;
}

?>
